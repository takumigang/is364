<?php

include 'Task.php';
include 'Project.php';

// пример использования классов
$project = new Project("Новый проект");

$task1 = new Task("Первая задача", "Описание первой задачи<br>");
$task2 = new Task("Вторая задача", "Описание второй задачи<br>");

// добавляет созданные задачи в проект
$project->addTask($task1);
$project->addTask($task2);

echo $project . "\n"; // выводит строковое представление проекта, что покажет его название и количество задач
echo $task1 . "\n"; // выводит строковое представление первой задачи
$task1->setStatus("Выполнено");
echo $task1->getStatus() . "\n";
