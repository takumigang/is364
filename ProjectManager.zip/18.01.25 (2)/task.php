<?php

class Task {
    private $title;
    private $description;
    private $status;

    public function __construct($title, $description) {
        $this->title = $title;
        $this->description = $description;
        $this->status = "Не выполнено";
    }

    public function __destruct() {
        echo "<br>Задача '{$this->title}' была удалена из памяти.\n";
    }

    public function __call($method, $arguments) { // метод __call, который обрабатывает вызовы несуществующих методов класса
        if (strpos($method, 'set') === 0) { // gроверяет, начинается ли имя вызываемого метода с set
            $property = strtolower(substr($method, 3)); // извлекает имя свойства, которое нужно изменить, убирая префикс set и приводя его к нижнему регистру
            if (property_exists($this, $property)) { // если свойство существует, изменяет его значение на первое значение из массива аргументов
                $this->$property = $arguments[0];
            }
        } elseif (strpos($method, 'get') === 0) { // если имя метода начинается с get, выполняет следующие действия
            $property = strtolower(substr($method, 3)); // извлекает имя свойства, которое нужно вернуть, убирая префикс get
            if (property_exists($this, $property)) { // если свойство существует, возвращает его значение
                return $this->$property;
            }
        }
    }

    public function __toString() { //  метод __toString, который определяет, как объект будет представлен в виде строки.
        return "<br>Задача: {$this->title} — {$this->status}";
    }
}
