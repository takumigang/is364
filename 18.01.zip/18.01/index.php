<?php
include 'Book.php';
include 'Reader.php';
include 'Library.php';

// Создание библиотеки и добавление книг и читателя
$library = new Library();
$book1 = new Book("Путь к успеху", "Николай Соболев", 2016);
$book2 = new Book("Убийство в восточном экспрессе", "Агата Кристи", 1960);
$library->addBook($book1);
$library->addBook($book2);
$reader1 = new Reader("Arseniy", "deryabichev@gmail.com");
$library->addReader($reader1);

// Проверка доступности книги
$bookToCheck = $library->findBook("Путь к успеху");
if ($bookToCheck !== null) {
    if ($bookToCheck->getAvailability()) {
        echo "Книга '{$bookToCheck->getTitle()}' доступна.<br>";
    } else {
        echo "Книга '{$bookToCheck->getTitle()}' недоступна.<br>";
    }
}

// Взятие книги
$reader1->borrowBook($bookToCheck);
echo "<br>'{$reader1->getName()}' взял книгу '{$bookToCheck->getTitle()}'.<br>";

// Вывод списка всех книг
echo "<br>Список всех книг в библиотеке:<br>";
$library->listBooks();

// Узнать информацию о читателе
echo "<br>Имя читателя: " . $reader1->getName() . "<br>";
echo "Email читателя: " . $reader1->getEmail() . "<br>";
?>


