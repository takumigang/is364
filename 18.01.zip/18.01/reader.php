<?php

class Reader {
    private $name;
    private $email;
    private $borrowedBooks;

    public function __construct($name, $email) {
        $this->name = $name; // инициализация свойств класса
        $this->email = $email;
        $this->borrowedBooks = [];
    }

    public function getName() {
        return $this->name;
    }

    public function getEmail() {
        return $this->email;
    }

    public function borrowBook($book) { // взятие книги
        if ($book->getAvailability()) { // доступна ли книга
            $this->borrowedBooks[] = $book;
            $book->setAvailability(false); // если доступна - книга становится false
        }
    }

    public function returnBook($book) { // вернуть книгу
        if (($key = array_search($book, $this->borrowedBooks)) !== false) { // взята ли книга
            unset($this->borrowedBooks[$key]);
            $book->setAvailability(true); // возвращаем книгу и она снова доступна
        }
    }
}
