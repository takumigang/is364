<?php

class Library {
    private $books;
    private $readers;

    public function __construct() {
        $this->books = [];
        $this->readers = [];
    }

    // добавление книги и читателя в библиотеку
    public function addBook($book) {
        $this->books[] = $book; // добавление книги в массив
    }

    public function addReader($reader) {
        $this->readers[] = $reader; // добавление читателя в массив
    }

    public function findBook($title) { // поиск книг
        foreach ($this->books as $book) { // поиск по массиву books
            if ($book->getTitle() === $title) { // книга найдена - возвращаем её
                return $book;
            }
        }
        return null; // если нет null
    }

    public function listBooks() { // все книги
        foreach ($this->books as $book) {
            echo $book->getTitle() . " by " . $book->getAuthor() . "<br>"; // инфо о каждой книге
        }
    }
}
