<?php
session_start();

$db = new mysqli('192.168.199.13', 'learn', 'learn', 'learn_kuznetsov364', '3306');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$post_id = $_GET['id'];
$stmt = $db->prepare("SELECT * FROM posts WHERE id = ?");
$stmt->bind_param('i', $post_id);
$stmt->execute();
$post = $stmt->get_result()->fetch_assoc();

if ($post && ($post['user_id'] == $_SESSION['user_id'] || $_SESSION['role'] == 'admin')) {
    $stmt = $db->prepare("DELETE FROM posts WHERE id = ?");
    $stmt->bind_param('i', $post_id);
    
    if ($stmt->execute()) {
        header('Location: posts.php?message=Post deleted successfully');
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
} else {
    echo "У вас нет прав для удаления этого поста.";
    exit;
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Удаление поста</title>
</head>
<body>
    <h1>Удаление поста</h1>
    <p>Пост удален успешно.</p>
    <p><a href="posts.php">Назад к постам</a></p>
</body>
</html>
