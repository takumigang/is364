<?php
$db = new mysqli('192.168.199.13', 'learn', 'learn', 'learn_kuznetsov364', '3306');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

$result = $db->query("SELECT p.id, p.title, p.content, u.username AS author_name, p.created_at 
                      FROM posts AS p 
                      JOIN users AS u ON p.user_id = u.id 
                      ORDER BY p.created_at DESC");

$posts = $result->fetch_all(MYSQLI_ASSOC);
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Все посты</title>
</head>
<body>

<style>

    *{
        text-decoration: none;
    }
    .cont{
        padding-top: 20px;
        display: flex;
        justify-content: center;
        flex-direction: column;
        align-items: center;
    }

    .mark{
        color: crimson;
        font-size: 22px;
    }

    .mark2{
        color: gray;
        font-size: 22px;  
    }
</style>
    <div class="cont">
        <h1>Все посты</h1>
        <ul>
            <?php foreach ($posts as $post): ?>
                <li>
                    <h3><?php echo $post['title']; ?></h3>
                    <p><?php echo $post['content']; ?></p>
                    <p>Автор: <?php echo $post['author_name']; ?></p>
                    <p>Создан: <?php echo $post['created_at']; ?></p>
                    <a href="edit_post.php?id=<?php echo $post['id']; ?>" class="mark2">Редактировать</a>
                    <a href="delete_post.php?id=<?php echo $post['id']; ?>" class="mark2">Удалить</a>
                </li>
            <?php endforeach; ?>
        </ul>
        <p><a href="create_post.php" class="mark">Создать новый пост</a></p>
    </div>
</body>
</html>
