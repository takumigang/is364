<?php
session_start();

$db = new mysqli('192.168.199.13', 'learn', 'learn', 'learn_kuznetsov364', '3306');

if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    $title = htmlspecialchars($_POST['title'], ENT_QUOTES, 'UTF-8');
    $content = htmlspecialchars($_POST['content'], ENT_QUOTES, 'UTF-8');

    $stmt = $db->prepare("INSERT INTO posts (user_id, title, content) VALUES (?, ?, ?)");
    $stmt->bind_param('iss', $user_id, $title, $content);
    
    if ($stmt->execute()) {
        header('Location: posts.php?message=Post created successfully');
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Создание поста</title>
</head>
<body>

<style>

    *{
        text-decoration: none;
    }
    .cont{
        padding-top: 50px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }

    .mark{
        color: crimson;
        font-size: 20px;
    }

    .btn{
        border: 1px solid black;
        border-radius: 5px;
        background: none;
        font-size: 18px;
        width: 140px;
        height: 30px;
    }

    .fd{
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        gap: 10px;
    }

    .bob{
        width: 240px;
        font-size: 18px;
        border: 1px solid black;
        border-radius: 5px;
        background: none;
    }
</style>
<div class="cont">
    <h1>Создание поста</h1>
        <form method="POST" class="fd">
            <input type="text" name="title" placeholder="Заголовок поста" class="bob">
            <textarea name="content" id="" cols="30" rows="6" placeholder="Содержание поста" class="bob"></textarea>
            <input type="submit" value="Создать пост" class="btn">
        </form>
    <p><a href="posts.php" class="mark">Перейти к постам</a></p>
</div>
</body>
</html>
