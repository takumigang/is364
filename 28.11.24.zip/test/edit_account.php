<?php
session_start();

$db = new mysqli('192.168.199.13', 'learn', 'learn', 'learn_kuznetsov364', '3306');

if ($db->connect_error) {
    die('Ошибка подключения: ' . $db->connect_error);
}

if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit;
}

$errorMessage = '';
$successMessage = '';
$userId = $_SESSION['user_id'];

// Получение текущих данных пользователя
$stmt = $db->prepare("SELECT username, email FROM users WHERE id = ?");
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Проверка на уникальность email
    $stmt = $db->prepare("SELECT * FROM users WHERE email = ? AND id != ?");
    $stmt->bind_param("si", $email, $userId);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $errorMessage = "Этот email уже зарегистрирован.";
    } else {
        // Обновление имени и email
        $stmt = $db->prepare("UPDATE users SET username = ?, email = ? WHERE id = ?");
        $stmt->bind_param("ssi", $username, $email, $userId);
        $stmt->execute();
        $successMessage = "Данные успешно обновлены!";

        // Обновление пароля, если указан
        if (!empty($password)) {
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $db->prepare("UPDATE users SET password = ? WHERE id = ?");
            $stmt->bind_param("si", $hashedPassword, $userId);
            $stmt->execute();
            $successMessage .= " Пароль успешно обновлен!";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Редактирование аккаунта</title>
</head>
<body>
<style>
    .cont{
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }

    .fd{
        display: flex;
        flex-direction: column;
    }

    .btn{
        border: 1px solid black;
        border-radius: 5px;
        background: none;
        font-size: 16px;
        width: 170px;
        height: 30px;
    }
</style>
<div class="cont">
    <h1>Редактирование аккаунта</h1>
    <?php if ($errorMessage): ?>
        <p style="color:red;"><?php echo htmlspecialchars($errorMessage); ?></p>
    <?php endif; ?>
    <?php if ($successMessage): ?>
        <p style="color:green;"><?php echo htmlspecialchars($successMessage); ?></p>
    <?php endif; ?>
    <form method="POST" class="fd">
        Имя: <input type="text" name="username" value="<?php echo htmlspecialchars($user['username']); ?>" required><br>
        Email: <input type="email" name="email" value="<?php echo htmlspecialchars($user['email']); ?>" required><br>
        Новый пароль: <input type="password" name="password"><br>
        <button type="submit" class="btn">Обновить данные</button>
    </form>
</div>
</body>
</html>
