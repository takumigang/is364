<?php
session_start();

$db = new mysqli('192.168.199.13', 'learn', 'learn', 'learn_kuznetsov364', '3306');

if ($db->connect_error) {
    die('Ошибка подключения: ' . $db->connect_error);
}

$errorMessage = '';

// Обработка формы регистрации
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);

    // Проверка на уникальность email
    $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $errorMessage = "Email уже зарегистрирован.";
    } else {
        // Хеширование пароля
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        
        // Вставка нового пользователя
        $stmt = $db->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
        $stmt->bind_param("sss", $username, $email, $hashedPassword);
        if ($stmt->execute()) {
            header('Location: login.php');
            exit;
        } else {
            $errorMessage = "Ошибка регистрации. Попробуйте еще раз.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Регистрация</title>
</head>
<body>
<style>
    .cont{
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }

    .fd{
        display: flex;
        flex-direction: column;
    }

    .btn{
        border: 1px solid black;
        border-radius: 5px;
        background: none;
        font-size: 16px;
        width: 170px;
        height: 30px;
    }
</style>

<div class="cont">
    <h1>Регистрация</h1>
    <?php if ($errorMessage): ?>
        <p style="color:red;"><?php echo htmlspecialchars($errorMessage); ?></p>
    <?php endif; ?>
    <form method="POST" class="fd">
        Имя: <input type="text" name="username" required><br>
        Email: <input type="email" name="email" required><br>
        Пароль: <input type="password" name="password"><br>
        <button type="submit" class="btn">Зарегистрироваться</button>
    </form>
</div>
</body>
</html>
