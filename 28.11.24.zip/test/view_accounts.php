<?php
session_start();

$db = new mysqli('192.168.199.13', 'learn', 'learn', 'learn_kuznetsov364', '3306');

if ($db->connect_error) {
    die('Ошибка подключения: ' . $db->connect_error);
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Получение всех пользователей
$result = $db->query("SELECT username, email FROM users");
$users = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Просмотр всех аккаунтов</title>
</head>
<body>
<style>
    .cont{
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }

    .fd{
        display: flex;
        flex-direction: column;
    }

    .btn{
        border: 1px solid black;
        border-radius: 5px;
        background: none;
        font-size: 16px;
        width: 170px;
        height: 30px;
    }
</style>
<div class="cont">
    <h1>Список пользователей</h1>
    <table>
        <tr>
            <th>Имя</th>
            <th>Email</th>
        </tr>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?php echo htmlspecialchars($user['username']); ?></td>
            <td><?php echo htmlspecialchars($user['email']); ?></td>
        </tr>
        <?php endforeach; ?>
    </table>
</div>
</body>
</html>
