<?php
session_start();

$db = new mysqli('192.168.199.13', 'learn', 'learn', 'learn_kuznetsov364', '3306');

if ($db->connect_error) {
    die('Ошибка подключения: ' . $db->connect_error);
}

$errorMessage = '';

// Обработка формы авторизации
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);
    $password = trim($_POST['password']);
    if (empty($password) or empty ($email))
    {
        echo 'Вы не ввели логин или пароль';

    }

    else {
          // Проверка пользователя в базе данных
    $stmt = $db->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();


    // Проверка, существует ли пользователь
    if ($user) {
        echo "Пароль для проверки: " . htmlspecialchars($user['PASSWORD']); 
        if (password_verify($password, $user['PASSWORD'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['username'] = $user['username'];
            $_SESSION['role'] = $user['role'];
            header('Location: view_accounts.php');
            exit;
        } else {
            $errorMessage = "Неверный email или пароль.";
        }
    } else {
        $errorMessage = "Пользователь не найден.";
    }
}
    }

  
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Авторизация</title>
</head>
<body>
<style>
    .cont{
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }

    .fd{
        display: flex;
        flex-direction: column;
    }

    .btn{
        border: 1px solid black;
        border-radius: 5px;
        background: none;
        font-size: 16px;
        width: 170px;
        height: 30px;
    }
</style>
<div class="cont">
    <h1>Авторизация</h1>
    <?php if ($errorMessage): ?>
        <p style="color:red;"><?php echo htmlspecialchars($errorMessage); ?></p>
    <?php endif; ?>
    <form method="POST" class="fd">
        Email: <input type="email" name="email" required><br>
        Пароль: <input type="password" name="password" required><br>
        <button type="submit" class="btn">Войти</button>
    </form>
</div>
</body>
</html>
