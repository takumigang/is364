<?php
session_start();

$db = new mysqli('192.168.199.13', 'learn', 'learn', 'learn_kuznetsov364', '3306');

if ($db->connect_error) {
    die('Ошибка подключения: ' . $db->connect_error);
}

if (!isset($_SESSION['user_id']) || $_SESSION['role'] !== 'admin') {
    header('Location: login.php');
    exit;
}

// Обработка формы изменения роли
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $userId = $_POST['user_id'];
    $role = $_POST['role'];

    // Обновление роли пользователя
    $stmt = $db->prepare("UPDATE users SET role = ? WHERE id = ?");
    $stmt->bind_param("si", $role, $userId);
    if ($stmt->execute()) {
        $successMessage = "Роль пользователя успешно обновлена.";
    } else {
        $errorMessage = "Ошибка обновления роли.";
    }
}

// Получение всех пользователей для управления ролями
$result = $db->query("SELECT id, username, role FROM users");
$users = $result->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <title>Управление правами доступа</title>
</head>
<body>
    <h1>Управление правами доступа</h1>
    <?php if (isset($successMessage)): ?>
        <p style="color:green;"><?php echo htmlspecialchars($successMessage); ?></p>
    <?php endif; ?>
    <?php if (isset($errorMessage)): ?>
        <p style="color:red;"><?php echo htmlspecialchars($errorMessage); ?></p>
    <?php endif; ?>
    <table>
        <tr>
            <th>Имя</th>
            <th>Роль</th>
            <th>Изменить роль</th>
        </tr>
        <?php foreach ($users as $user): ?>
        <tr>
            <td><?php echo htmlspecialchars($user['username']); ?></td>
            <td><?php echo htmlspecialchars($user['role']); ?></td>
            <td>
                <form method="POST">
                    <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                    <select name="role">
                        <option value="user" <?php echo $user['role'] === 'user' ? 'selected' : ''; ?>>Пользователь</option>
                        <option value="admin" <?php echo $user['role'] === 'admin' ? 'selected' : ''; ?>>Администратор</option>
                    </select>
                    <button type="submit">Изменить</button>
                </form>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>
</body>
</html>
