<?php
// Подключение к базе данных
$db = new mysqli('192.168.199.13', 'learn', 'learn', 'learn_364kuznetsov', '3306');
$db->set_charset("utf8mb4");

// Проверка соединения
if ($db->connect_error) {
    die("Connection failed: " . $db->connect_error);
}

// Обработка формы фильтрации
$category = isset($_POST['category']) ? $_POST['category'] : '';
$min_price = isset($_POST['min_price']) ? $_POST['min_price'] : '';
$max_price = isset($_POST['max_price']) ? $_POST['max_price'] : '';
$search_name = isset($_POST['search_name']) ? $_POST['search_name'] : '';

// Создание SQL-запроса с условиями
$sql = "SELECT * FROM products WHERE 1=1";
if ($category) {
    $sql .= " AND category = ?";
}
if ($min_price !== '') {
    $sql .= " AND price >= ?";
}
if ($max_price !== '') {
    $sql .= " AND price <= ?";
}
if ($search_name) {
    $sql .= " AND name LIKE ?";
}

// Подготовка и выполнение запроса
$stmt = $db->prepare($sql);

$params = [];
$types = '';
if ($category) {
    $params[] = $category;
    $types .= 's';
}
if ($min_price !== '') {
    $params[] = $min_price;
    $types .= 'd';
}
if ($max_price !== '') {
    $params[] = $max_price;
    $types .= 'd';
}
if ($search_name) {
    $search_name = '%' . $search_name . '%';
    $params[] = $search_name;
    $types .= 's';
}

if ($types) {
    $stmt->bind_param($types, ...$params);
}

$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="ru">

<head>
    <meta charset="UTF-8">
    <title>Фильтрация товаров</title>
</head>

<body>

    <h1 class="txt">Фильтр товаров</h1>

    <style>
        .txt {
            display: flex;
            justify-content: center;
        }

        .btn {
            border: 1px solid crimson;
            border-radius: 5px;
            background: none;
            width: 120px;
            height: 22px;
        }

        .bob {
            font-weight: 600;
        }

        .forma {
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            gap: 8px;
            ;
        }

        .cont {
            display: flex;
            justify-content: center;
        }

        .ta {
            text-align: center;
        }

        .inp {
            width: 180px;
            border: 1px solid black;
            border-radius: 5px;
        }
    </style>

    <form method="POST" action="" class="forma">
        <label for="category">Категория:</label>
        <select name="category" id="category" class="inp">
            <option value="">Все</option>
            <option value="Электроника">Электроника</option>
            <option value="Одежда">Одежда</option>
            <option value="Мебель">Мебель</option>
        </select>

        <label for="min_price">Минимальная цена:</label>
        <input type="number" name="min_price" id="min_price" step="0.01" class="inp">

        <label for="max_price">Максимальная цена:</label>
        <input type="number" name="max_price" id="max_price" step="0.01" class="inp">

        <label for="search_name">Поиск по имени:</label>
        <input type="text" name="search_name" id="search_name" class="inp">

        <input type="submit" value="Фильтровать" class="btn">
    </form>

    <h2 class="ta">Список товаров</h2>
    <div class="cont">
        <ol>
            <?php while ($product = $result->fetch_assoc()): ?>
                <li>
                    <p class="bob">
                        <?= htmlspecialchars($product['name']) ?>
                    </p> Категория:
                    <?= htmlspecialchars($product['category']) ?>
                    <p class="bob">Цена:
                        <?= htmlspecialchars($product['price']) ?> ₽
                    </p>
                </li>
            <?php endwhile; ?>
        </ol>
    </div>

    <?php
    // Закрытие соединения
    $stmt->close();
    $db->close();
    ?>
</body>

</html>