<?php
function load_products_from_ini($filename) {
    if (!file_exists($filename)) {
        die("Файл $filename не найден.");
    }
    $products = parse_ini_file($filename, true);
    return $products;
}
function display_product_card($product) {
    echo "<div class='df' style='border: 1px solid gray; border-radius: 15px; padding: 15px; margin: 10px; width: 300px;'>";
    echo "<h2 style='color: darkslateblue;'>{$product['name']}</h2>";
    echo "<p style='color: darkslategray; font-size: 18px;'><strong>Описание:</strong></p><mark class='lat'>{$product['description']}</mark>";
    echo "<p style='color: darkslategray; font-size: 18px;'><strong>Цена:</strong></p><mark class='lat'>{$product['price']} ₽</mark>";
    echo "<p style='color: darkslategray; font-size: 18px;'><strong>В наличии:</strong></p><mark class='lat'>{$product['stock']} шт.</mark>";
    echo "<p style='color: darkslategray; font-size: 18px;'><strong>ID товара:</strong></p><mark class='lat'>{$product['id']}</mark>";
    echo "</div>";
}
function display_all_products($products) {
    echo "<div style='display: flex; flex-wrap: wrap;'>";
    foreach ($products as $product) {
        display_product_card($product);
    }
    echo "</div>";
}
$filename = 'products.ini';
$products = load_products_from_ini($filename);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>20/11/2024</title>
</head>
<body>
<style>
    .title{
        display: flex;
        justify-content: center;
        font-size: 30px;
        font-weight: bold;
    }

    .lat{
        font-size: 18px;
        background: none;
    }

    .df{
        display: flex;
        flex-direction: column;
        align-items: center;
    }
</style>

    <p class="title">Каталог товаров</p>
    <?php display_all_products($products); ?>
</body>
</html>